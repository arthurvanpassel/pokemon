function hideLoader() {
  document.getElementById('loadingAnim').style.display = "none";
  document.getElementById('loadingText').style.display = "none";
}
