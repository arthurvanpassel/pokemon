const people = [
  {
      id: 4,
      name: 'Charmander',
      height: '6',
      weight: '85',
      types: 'fire'
  },
  {
      id: 25,
      name: 'Pikachu',
      height: '4',
      weight: '60',
      types: 'electric'
  }
];

module.exports = people;
