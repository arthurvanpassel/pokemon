const PORT = 1337;
const STATUS = {
    OK: 'OK',
    ERROR: 'ERROR',
}
const DEFAULTS = { }

module.exports = {
    PORT,
    STATUS,
    DEFAULTS,
}
