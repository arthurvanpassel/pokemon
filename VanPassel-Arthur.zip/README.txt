OM DE POKEMON APP TE RUNNEN, MOET JE IN BEIDE MAPPEN (api & PokemonSite) EEN COMMANDPROMPT STARTEN EN VOLGENDE LIJNEN INGEVEN:

	npm install
	yarn start

DE LINK NAAR DE ONLINE VERSIE IS:

http://arthur.vanpassel.mtantwerp.eu/pokemon


